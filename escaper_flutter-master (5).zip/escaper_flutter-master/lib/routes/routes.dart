class RoutesName {
  // static const String Splash = "/";
  // static const String IntroductionScreen = '/introductionScreen';
  static const String IntroductionScreen = '/';
  static const String Login = '/login';
  static const String Home = '/home';
  static const String TabScreen = "/bottomTab/bottomTabScreen";
}
