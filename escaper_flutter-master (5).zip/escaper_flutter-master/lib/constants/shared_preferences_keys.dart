import 'package:flutter/material.dart';
import 'package:new_motel/constants/themes.dart';
import 'package:new_motel/models/enum.dart';
import 'package:new_motel/motel_app.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferencesKeys {
  setStringListData({required String key, required List<String> text}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? list = await getStringListData(key: "listFavorites");
    list = list == null ? [] : text;
    await prefs.setStringList(key, text);
  }

  _setIntData({required String key, required int id}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setInt(key, id);
  }

//   _setBoolData({required String key, required bool text}) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.setBool(key, text);
//   }

  Future<List<String>?> getStringListData({required String key}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(key);
  }

  Future<int?> _getIntData({required String key}) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getInt(key);
  }

//   Future<bool?> _getBoolData({required String key}) async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     return prefs.getBool(key);
//   }

  Future<ThemeModeType> getThemeMode() async {
    int? index = await _getIntData(key: 'ThemeModeType');
    if (index != null) {
      return ThemeModeType.values[index];
    } else {
      return ThemeModeType.system;
    }
  }

  Future setThemeMode(ThemeModeType type) async {
    await _setIntData(key: 'ThemeModeType', id: type.index);
  }

  Future<FontFamilyType> getFontType() async {
    int? index = await _getIntData(key: 'FontType');
    if (index != null) {
      return FontFamilyType.values[index];
    } else {
      return FontFamilyType.WorkSans; // Default we set work span font
    }
  }

  Future setFontType(FontFamilyType type) async {
    await _setIntData(key: 'FontType', id: type.index);
  }

  Future<ColorType> getColorType() async {
    int? index = await _getIntData(key: 'ColorType');
    if (index != null) {
      return ColorType.values[index];
    } else {
      return ColorType.Malibu; // Default we set Verdigris
    }
  }

  Future setColorType(ColorType type) async {
    await _setIntData(key: 'ColorType', id: type.index);
  }

  Future<LanguageType> getLanguageType() async {
    int? index = await _getIntData(key: 'Languagetype');
    if (index != null) {
      return LanguageType.values[index];
    } else {
      if (applicationcontext != null) {
        LanguageType type = LanguageType.en;
        final Locale myLocale = Localizations.localeOf(applicationcontext!);
        if (myLocale.languageCode != '' && myLocale.languageCode.length == 2) {
          for (var item in LanguageType.values.toList()) {
            if (myLocale.languageCode == item.toString().split(".")[1]) {
              type = item;
            }
          }
        }
        return type;
      } else {
        return LanguageType.en; // Default we set english
      }
    }
  }

  Future setLanguageType(LanguageType language) async {
    await _setIntData(key: 'Languagetype', id: language.index);
  }
}
