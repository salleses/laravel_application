import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:new_motel/constants/localfiles.dart';
import 'package:new_motel/models/room_data.dart';

class HotelListData {
  String idhotel;
  String imagePath;
  String titleTxt;
  String subTxt;
  DateText? date;
  String dateTxt;
  String roomSizeTxt;
  RoomData? roomData;
  double dist;
  double rating;
  int reviews;
  int perNight;
  bool isSelected;
  PeopleSleeps? peopleSleeps;
  LatLng? latlng;

  HotelListData({
    this.idhotel = '',
    this.imagePath = '',
    this.titleTxt = '',
    this.subTxt = "",
    this.dateTxt = "",
    this.roomSizeTxt = "",
    this.roomData,
    this.dist = 1.8,
    this.reviews = 80,
    this.rating = 4.5,
    this.perNight = 180,
    this.isSelected = false,
    this.date,
    this.peopleSleeps,
    this.latlng,
  });

  static List<HotelListData> hotelList = [
    HotelListData(
        idhotel: 'aaa1',
        imagePath: Localfiles.hotel_1,
        titleTxt: 'Grand Royal Hotel',
        subTxt: 'Wembley, London',
        dist: 2.0,
        reviews: 80,
        rating: 4.4,
        perNight: 180,
        roomData: RoomData(1, 2),
        isSelected: true,
        date: DateText(1, 5),
        latlng: LatLng(51.5118252803728, -0.0038627417911247233)),
    HotelListData(
        idhotel: 'aaa2',
        imagePath: Localfiles.hotel_2,
        titleTxt: 'Queen Hotel',
        subTxt: 'Wembley, London',
        dist: 4.0,
        reviews: 74,
        rating: 4.5,
        perNight: 200,
        roomData: RoomData(1, 3),
        isSelected: false,
        date: DateText(2, 6),
        latlng: LatLng(51.51918241746268, -0.0024030109241437188)),
    HotelListData(
        idhotel: 'aaa3',
        imagePath: Localfiles.hotel_3,
        titleTxt: 'Grand Royal Hotel',
        subTxt: 'Wembley, London',
        dist: 3.0,
        reviews: 62,
        rating: 4.0,
        perNight: 60,
        roomData: RoomData(2, 3),
        isSelected: false,
        date: DateText(5, 9),
        latlng: LatLng(51.516421971586205, -0.019659942092069857)),
    HotelListData(
        idhotel: 'aaa4',
        imagePath: Localfiles.hotel_4,
        titleTxt: 'Queen Hotel',
        subTxt: 'Wembley, London',
        dist: 7.0,
        reviews: 90,
        rating: 4.4,
        perNight: 170,
        isSelected: false,
        roomData: RoomData(2, 2),
        date: DateText(1, 5),
        latlng: LatLng(51.516421971586205, -0.014659942092069857)),
    HotelListData(
        idhotel: 'aaa5',
        imagePath: Localfiles.hotel_5,
        titleTxt: 'Grand Royal Hotel',
        subTxt: 'Wembley, London',
        dist: 2.0,
        reviews: 240,
        rating: 4.5,
        isSelected: false,
        perNight: 200,
        roomData: RoomData(1, 7),
        date: DateText(1, 4),
        latlng: LatLng(51.516421971586205, -0.014659942092069857)),
  ];

  static List<HotelListData> popularList = [
    HotelListData(
      imagePath: Localfiles.imgRioDeJaneiro,
      titleTxt: 'Rio de Janeiro',
    ),
    HotelListData(
      imagePath: Localfiles.imgSaoPaulo,
      titleTxt: 'São Paulo',
    ),
    HotelListData(
      imagePath: Localfiles.imgGramado,
      titleTxt: 'Gramado',
    ),
    HotelListData(
      imagePath: Localfiles.imgFlorianopolis,
      titleTxt: 'Florianópolis',
    ),
    HotelListData(
      imagePath: Localfiles.imgFoz,
      titleTxt: 'Foz do Iguaçu',
    ),
    HotelListData(
      imagePath: Localfiles.imgSalvador,
      titleTxt: 'Salvador',
    ),
    HotelListData(
      imagePath: Localfiles.imgCuritiba,
      titleTxt: 'Curitiba',
    ),
    HotelListData(
      imagePath: Localfiles.imgBeloHorizonte,
      titleTxt: 'Belo Horizonte',
    ),
  ];

  static List<HotelListData> reviewsList = [
    HotelListData(
      imagePath: Localfiles.avatar1,
      titleTxt: 'Alexia Jane',
      subTxt: 'This is located in a great spot close to shops and bars, very quiet location',
      rating: 8.0,
      dateTxt: '21 May, 2019',
    ),
    HotelListData(
      imagePath: Localfiles.avatar3,
      titleTxt: 'Jacky Depp',
      subTxt:
          'Good staff, very comfortable bed, very quiet location, place could do with an update',
      rating: 8.0,
      dateTxt: '21 May, 2019',
    ),
    HotelListData(
      imagePath: Localfiles.avatar5,
      titleTxt: 'Alex Carl',
      subTxt: 'This is located in a great spot close to shops and bars, very quiet location',
      rating: 6.0,
      dateTxt: '21 May, 2019',
    ),
    HotelListData(
      imagePath: Localfiles.avatar2,
      titleTxt: 'May June',
      subTxt:
          'Good staff, very comfortable bed, very quiet location, place could do with an update',
      rating: 9.0,
      dateTxt: '21 May, 2019',
    ),
    HotelListData(
      imagePath: Localfiles.avatar4,
      titleTxt: 'Lesley Rivas',
      subTxt: 'This is located in a great spot close to shops and bars, very quiet location',
      rating: 8.0,
      dateTxt: '21 May, 2019',
    ),
    HotelListData(
      imagePath: Localfiles.avatar6,
      titleTxt: 'Carlos Lasmar',
      subTxt:
          'Good staff, very comfortable bed, very quiet location, place could do with an update',
      rating: 7.0,
      dateTxt: '21 May, 2019',
    ),
    HotelListData(
      imagePath: Localfiles.avatar7,
      titleTxt: 'Oliver Smith',
      subTxt: 'This is located in a great spot close to shops and bars, very quiet location',
      rating: 9.0,
      dateTxt: '21 May, 2019',
    ),
  ];

  static List<HotelListData> romeList = [
    HotelListData(
        imagePath: 'assets/images/room_1.jpg assets/images/room_2.jpg assets/images/room_3.jpg',
        titleTxt: 'Deluxe Room',
        perNight: 180,
        dateTxt: 'Sleeps 3 people',
        roomData: RoomData(2, 2)),
    HotelListData(
        imagePath: 'assets/images/room_4.jpg assets/images/room_5.jpg assets/images/room_6.jpg',
        titleTxt: 'Premium Room',
        perNight: 200,
        dateTxt: 'Sleeps 3 people + 2 children',
        roomData: RoomData(3, 2)),
    HotelListData(
        imagePath: 'assets/images/room_7.jpg assets/images/room_8.jpg assets/images/room_9.jpg',
        titleTxt: 'Queen Room',
        perNight: 240,
        dateTxt: 'Sleeps 4 people + 4 children',
        roomData: RoomData(4, 4)),
    HotelListData(
        imagePath: 'assets/images/room_10.jpg assets/images/room_11.jpg assets/images/room_12.jpg',
        titleTxt: 'King Room',
        perNight: 240,
        dateTxt: 'Sleeps 4 people + 4 children',
        roomData: RoomData(4, 4)),
    HotelListData(
        imagePath: 'assets/images/room_11.jpg assets/images/room_1.jpg assets/images/room_2.jpg',
        titleTxt: 'Hollywood Twin\nRoom',
        perNight: 260,
        dateTxt: 'Sleeps 4 people + 4 children',
        roomData: RoomData(4, 4)),
  ];

  static List<HotelListData> hotelTypeList = [
    HotelListData(
      imagePath: Localfiles.hotel_Type_1,
      titleTxt: 'hotel_data',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_2,
      titleTxt: 'Backpacker_data',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_3,
      titleTxt: 'Resort_data',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_4,
      titleTxt: 'villa_data',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_5,
      titleTxt: 'apartment',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_6,
      titleTxt: 'guest_house',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_7,
      titleTxt: 'motel',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_8,
      titleTxt: 'accommodation',
      isSelected: false,
    ),
    HotelListData(
      imagePath: Localfiles.hotel_Type_9,
      titleTxt: 'Bed_breakfast',
      isSelected: false,
    ),
  ];
  static List<HotelListData> lastsSearchesList = [
    HotelListData(
      imagePath: Localfiles.popular_4,
      titleTxt: 'London',
      roomData: RoomData(1, 3),
      date: DateText(12, 22),
      dateTxt: '12 - 22 Dec',
    ),
    HotelListData(
      imagePath: Localfiles.popular_1,
      titleTxt: 'Paris',
      roomData: RoomData(1, 3),
      date: DateText(12, 24),
      dateTxt: '12 - 24 Sep',
    ),
    HotelListData(
      imagePath: Localfiles.city_3,
      titleTxt: 'New York',
      roomData: RoomData(1, 3),
      date: DateText(20, 22),
      dateTxt: '20 - 22 Sep',
    ),
    HotelListData(
      imagePath: Localfiles.city_4,
      titleTxt: 'Tokyo',
      roomData: RoomData(12, 22),
      date: DateText(12, 22),
      dateTxt: '12 - 22 Nov',
    ),
    HotelListData(
      imagePath: Localfiles.city_5,
      titleTxt: 'Shanghai',
      roomData: RoomData(10, 15),
      date: DateText(10, 15),
      dateTxt: '10 - 15 Dec',
    ),
    HotelListData(
      imagePath: Localfiles.city_6,
      titleTxt: 'Moscow',
      roomData: RoomData(12, 14),
      date: DateText(12, 14),
      dateTxt: '12 - 14 Dec',
    ),
  ];
}
