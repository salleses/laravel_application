import 'package:flutter/material.dart';
import 'package:new_motel/constants/text_styles.dart';
import 'package:new_motel/constants/themes.dart';

class FloatingButtonOption extends StatelessWidget {
  const FloatingButtonOption(
      {Key? key,
      required this.icon,
      required this.text,
      required this.x,
      required this.y,
      required this.isOpened})
      : super(key: key);
  final Widget icon;
  final String text;
  final double x;
  final double y;
  final bool isOpened;

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      duration: Duration(milliseconds: 400),
      opacity: isOpened ? 1.0 : 0.0,
      child: Container(
        height: 65,
        width: 80,
        decoration: BoxDecoration(
          color: Colors.red[300],
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Color(0xff66388d),
              // Color(0xff8d82b3),
              Color(0xff284e8a),
            ],
          ),
          borderRadius: BorderRadius.all(Radius.elliptical(17, 20)),
        ),
        transform: Matrix4.translationValues(
          x,
          y,
          0.0,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon,
            Text(text,
                style: TextStyles(context).getRegularStyle().copyWith(color: AppTheme.whiteColor))
          ],
        ),
      ),
    );
  }
}
