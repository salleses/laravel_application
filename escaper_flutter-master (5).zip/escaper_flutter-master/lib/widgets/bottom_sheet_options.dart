import 'package:flutter/material.dart';
import 'package:new_motel/constants/localfiles.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:new_motel/constants/text_styles.dart';
import 'package:new_motel/constants/themes.dart';
import 'package:new_motel/language/appLocalizations.dart';
import 'package:new_motel/routes/route_names.dart';

class BottomSheetOptions extends StatelessWidget {
  const BottomSheetOptions({Key? key, required this.animationController}) : super(key: key);
  final AnimationController animationController;

  topRightColor() {
    print("Light Mode: " + AppTheme.isLightMode.toString());
    return AppTheme.isLightMode ? Color(0xff740699) : Color(0xff740699);
  }

  bottomLeftColor() {
    return AppTheme.isLightMode ? Color(0xff1d4e89) : Color(0xff1d4e89);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              topRightColor(),
              bottomLeftColor(),
              // //Black mode
              // // Color(0x77740699),
              // // Color(0x551d4e89),
              // //White Mode
              // Color(0xff740699),
              // Color(0xff1d4e89),
            ],
          ),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      // margin: EdgeInsets.only(left: 10, right: 10),
      padding: EdgeInsets.only(top: 10, left: 10, right: 10, bottom: 30),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 5),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: GestureDetector(
                  //TODO: buscar do gerenciador de estados o animationController
                  onTap: () => NavigationServices(context).gotoTabScreen(replace: true),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    // margin: EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(children: [
                      SvgPicture.asset(
                        Localfiles.iconPesquisa,
                        fit: BoxFit.contain,
                        height: 25,
                        color: Colors.white,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(AppLocalizations(context).of("explore"),
                          style: TextStyles(context)
                              .getRegularStyle()
                              .copyWith(color: AppTheme.whiteColor))
                    ]),
                  ),
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: GestureDetector(
                  //TODO: buscar do gerenciador de estados o animationController
                  onTap: () => NavigationServices(context).gotoMyTripsScreen(1),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    margin: EdgeInsets.only(left: 5, right: 5),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(children: [
                      SvgPicture.asset(
                        Localfiles.iconFavoritos,
                        fit: BoxFit.contain,
                        height: 25,
                        color: Colors.white,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(AppLocalizations(context).of("favorites"),
                          style: TextStyles(context)
                              .getRegularStyle()
                              .copyWith(color: AppTheme.whiteColor))
                    ]),
                  ),
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: GestureDetector(
                  //TODO: buscar do gerenciador de estados o animationController
                  onTap: () => NavigationServices(context).gotoMyTripsScreen(0),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    // margin: EdgeInsets.only(left: 10),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(children: [
                      SvgPicture.asset(
                        Localfiles.iconVouchers,
                        fit: BoxFit.contain,
                        height: 25,
                        color: Colors.white,
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(AppLocalizations(context).of("upcoming"),
                          style: TextStyles(context)
                              .getRegularStyle()
                              .copyWith(color: AppTheme.whiteColor))
                    ]),
                  ),
                ),
              )
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: GestureDetector(
                  onTap: () => NavigationServices(context).gotoEditProfile(),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    // margin: EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(children: [
                      SvgPicture.asset(
                        Localfiles.iconPerfil,
                        fit: BoxFit.contain,
                        height: 25,
                        color: Colors.white,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(AppLocalizations(context).of("profile"),
                          style: TextStyles(context)
                              .getRegularStyle()
                              .copyWith(color: AppTheme.whiteColor))
                    ]),
                  ),
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: GestureDetector(
                  onTap: () => null,
                  child: Container(
                    padding: EdgeInsets.all(10),
                    margin: EdgeInsets.only(left: 5, right: 5),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(children: [
                      SvgPicture.asset(
                        Localfiles.iconContato,
                        height: 25,
                        // fit: BoxFit.contain,
                        color: Colors.white,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(AppLocalizations(context).of("contact"),
                          style: TextStyles(context)
                              .getRegularStyle()
                              .copyWith(color: AppTheme.whiteColor))
                    ]),
                  ),
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                flex: 1,
                child: GestureDetector(
                  onTap: () => NavigationServices(context).gotoSettingsScreen(),
                  child: Container(
                    padding: EdgeInsets.all(10),
                    // margin: EdgeInsets.only(left: 10),
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(children: [
                      SvgPicture.asset(
                        Localfiles.iconAjustes,
                        fit: BoxFit.contain,
                        height: 25,
                        color: Colors.white,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(AppLocalizations(context).of("setting_text"),
                          style: TextStyles(context)
                              .getRegularStyle()
                              .copyWith(color: AppTheme.whiteColor))
                    ]),
                  ),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
