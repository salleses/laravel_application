import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:new_motel/constants/localfiles.dart';
import 'package:new_motel/constants/themes.dart';
import 'package:new_motel/models/hotel_list_data.dart';
import 'package:new_motel/modules/hotel_booking/map_hotel_view.dart';
import 'package:new_motel/modules/hotel_booking/components/time_date_view.dart';
import 'package:new_motel/routes/route_names.dart';
import 'dart:ui' as ui;

class MapAndListView extends StatefulWidget {
  final List<HotelListData> hotelList;
  final Widget searchBarUI;
  const MapAndListView({Key? key, required this.hotelList, required this.searchBarUI})
      : super(key: key);

  @override
  _MapAndListViewState createState() => _MapAndListViewState();
}

class _MapAndListViewState extends State<MapAndListView> {
  List<HotelListData> hotelList = [];
  late Widget searchBarUI;
  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(51.511004, -0.001320),
    zoom: 14.4746,
  );
  Completer<GoogleMapController> _controller = Completer();
  GoogleMapController? mapController;
  PageController scrollController = PageController();
  bool isListen = false;
  Set<Marker> markers = {};

  BitmapDescriptor? escaperPin;

  addListener() {
    if (isListen == false) {
      scrollController.addListener(() {
        debugPrint("Caiu malandro: " + scrollController.page!.toInt().toString());
        moveCamera();
      });
      isListen = true;
    }
  }

  moveCamera() {
    var latlng = LatLng(hotelList[scrollController.page!.toInt()].latlng!.latitude,
        hotelList[scrollController.page!.toInt()].latlng!.longitude - 0.00300);
    mapController!.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: latlng, zoom: 14.0, bearing: 45.0, tilt: 45.0)));
  }

  addMarkers(HotelListData data) {
    var a = Marker(markerId: MarkerId("dsds"), position: data.latlng!, icon: escaperPin!);
  }

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }

  void loadPin() async {
    final Uint8List markerIcon = await getBytesFromAsset('assets/images/Pin_Escaper.png', 60);

    escaperPin = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(24, 24)), 'assets/images/Pin_Escaper.png');

    // int index = 0;
    hotelList.asMap().forEach((index, hotel) {
      markers.add(
        Marker(
            markerId: MarkerId(index.toString()),
            // icon: escaperPin!,
            icon: BitmapDescriptor.fromBytes(markerIcon),
            onTap: () {
              scrollController.animateToPage(index,
                  duration: Duration(milliseconds: 400), curve: Curves.easeIn);
            },
            position: hotel.latlng!),
      );
      // index++;
    });
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    searchBarUI = widget.searchBarUI;
    hotelList = widget.hotelList;
    addListener();
    loadPin();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: <Widget>[
          searchBarUI,
          TimeDateView(),
          Expanded(
            child: Stack(
              children: <Widget>[
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: GoogleMap(
                        mapType: MapType.normal,
                        initialCameraPosition: _kGooglePlex,
                        markers: markers,
                        onMapCreated: (GoogleMapController controller) {
                          mapController = controller;
                          _controller.complete(controller);
                        },
                      ),
                      // Image.asset(
                      //   Localfiles.mapImage,
                      //   fit: BoxFit.cover,
                      // ),
                    ),
                    Container(
                      height: 80,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Theme.of(context).scaffoldBackgroundColor.withOpacity(1.0),
                            Theme.of(context).scaffoldBackgroundColor.withOpacity(0.4),
                            Theme.of(context).scaffoldBackgroundColor.withOpacity(0.0),
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                        ),
                      ),
                    ),
                  ] +
                  // getMapPinUI(state) +
                  [
                    Positioned(
                      bottom: 0,
                      right: 0,
                      left: 0,
                      child: Container(
                        height: 156,
                        // color: Colors.green,
                        child: PageView.builder(
                          itemCount: hotelList.length,
                          // padding: ,
                          scrollDirection: Axis.horizontal,
                          controller: scrollController,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding: EdgeInsets.only(top: 8, bottom: 8, right: 16),
                              child: MapHotelListView(
                                callback: () {
                                  NavigationServices(context)
                                      .gotoRoomBookingScreen(hotelList[index].titleTxt);
                                },
                                hotelData: hotelList[index],
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
            ),
          )
        ],
      ),
    );
  }

  List<Widget> getMapPinUI(Function(void Function()) state) {
    List<Widget> list = [];

    for (var i = 0; i < hotelList.length; i++) {
      double? top;
      double? left;
      double? right;
      double? bottom;
      if (i == 0) {
        top = 150;
        left = 50;
      } else if (i == 1) {
        top = 50;
        right = 50;
      } else if (i == 2) {
        top = 40;
        left = 10;
      } else if (i == 3) {
        bottom = 260;
        right = 140;
      } else if (i == 4) {
        bottom = 160;
        right = 20;
      }
      list.add(
        Positioned(
          top: top,
          left: left,
          right: right,
          bottom: bottom,
          child: Container(
            decoration: BoxDecoration(
              color: hotelList[i].isSelected ? AppTheme.primaryColor : AppTheme.backgroundColor,
              borderRadius: BorderRadius.all(Radius.circular(24.0)),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: AppTheme.secondaryTextColor,
                  blurRadius: 16,
                  offset: Offset(4, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.all(Radius.circular(24.0)),
                onTap: () {
                  if (hotelList[i].isSelected == false) {
                    state(() {
                      hotelList.forEach((f) {
                        f.isSelected = false;
                      });
                      hotelList[i].isSelected = true;
                    });
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 8),
                  child: Text(
                    "\$${hotelList[i].perNight}",
                    style: TextStyle(
                        color: hotelList[i].isSelected
                            ? AppTheme.backgroundColor
                            : AppTheme.primaryColor,
                        fontSize: 18,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }
    return list;
  }
}

// class MapAndListView extends StatelessWidget {
//   final List<HotelListData> hotelList;
//   final Widget searchBarUI;
//   static final CameraPosition _kGooglePlex = CameraPosition(
//     target: LatLng(51.511004, -0.001320),
//     zoom: 14.4746,
//   );
//   Completer<GoogleMapController> _controller = Completer();
//   GoogleMapController? mapController;
//   PageController scrollController = PageController();
//   bool isListen = false;

//   BitmapDescriptor? escaperPin;

//   addListener() {
//     if (isListen == false) {
//       scrollController.addListener(() {
//         debugPrint("Caiu malandro: " + scrollController.page!.toInt().toString());
//         moveCamera();
//       });
//       isListen = true;
//     }
//   }

//   moveCamera() {
//     mapController!.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
//         target: hotelList[scrollController.page!.toInt()].latlng!,
//         zoom: 14.0,
//         bearing: 45.0,
//         tilt: 45.0)));
//   }

//   addMarkers(HotelListData data) {
//     var a = Marker(markerId: MarkerId("dsds"), position: data.latlng!, icon: escaperPin!);
//   }

//   void loadPin() async {
//     escaperPin = await BitmapDescriptor.fromAssetImage(
//         ImageConfiguration(size: Size(48, 48)), 'assets/images/PinEscaper.png');
//   }

//   MapAndListView({Key? key, required this.hotelList, required this.searchBarUI}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     addListener();
//     loadPin();

//     return Expanded(
//       child: StatefulBuilder(
//         builder: (context, state) {
//           return Column(
//             children: <Widget>[
//               searchBarUI,
//               TimeDateView(),
//               Expanded(
//                 child: Stack(
//                   children: <Widget>[
//                         SizedBox(
//                           width: MediaQuery.of(context).size.width,
//                           child: GoogleMap(
//                             mapType: MapType.normal,
//                             initialCameraPosition: _kGooglePlex,
//                             onMapCreated: (GoogleMapController controller) {
//                               mapController = controller;
//                               _controller.complete(controller);
//                             },
//                           ),
//                           // Image.asset(
//                           //   Localfiles.mapImage,
//                           //   fit: BoxFit.cover,
//                           // ),
//                         ),
//                         Container(
//                           height: 80,
//                           decoration: BoxDecoration(
//                             gradient: LinearGradient(
//                               colors: [
//                                 Theme.of(context).scaffoldBackgroundColor.withOpacity(1.0),
//                                 Theme.of(context).scaffoldBackgroundColor.withOpacity(0.4),
//                                 Theme.of(context).scaffoldBackgroundColor.withOpacity(0.0),
//                               ],
//                               begin: Alignment.topCenter,
//                               end: Alignment.bottomCenter,
//                             ),
//                           ),
//                         ),
//                       ] +
//                       // getMapPinUI(state) +
//                       [
//                         Positioned(
//                           bottom: 0,
//                           right: 0,
//                           left: 0,
//                           child: Container(
//                             height: 156,
//                             // color: Colors.green,
//                             child: PageView.builder(
//                               itemCount: hotelList.length,
//                               // padding: ,
//                               scrollDirection: Axis.horizontal,
//                               controller: scrollController,
//                               itemBuilder: (context, index) {
//                                 return Padding(
//                                   padding: EdgeInsets.only(top: 8, bottom: 8, right: 16),
//                                   child: MapHotelListView(
//                                     callback: () {
//                                       NavigationServices(context)
//                                           .gotoRoomBookingScreen(hotelList[index].titleTxt);
//                                     },
//                                     hotelData: hotelList[index],
//                                   ),
//                                 );
//                               },
//                             ),
//                           ),
//                         ),
//                       ],
//                 ),
//               )
//             ],
//           );
//         },
//       ),
//     );
//   }

//   List<Widget> getMapPinUI(Function(void Function()) state) {
//     List<Widget> list = [];

//     for (var i = 0; i < hotelList.length; i++) {
//       double? top;
//       double? left;
//       double? right;
//       double? bottom;
//       if (i == 0) {
//         top = 150;
//         left = 50;
//       } else if (i == 1) {
//         top = 50;
//         right = 50;
//       } else if (i == 2) {
//         top = 40;
//         left = 10;
//       } else if (i == 3) {
//         bottom = 260;
//         right = 140;
//       } else if (i == 4) {
//         bottom = 160;
//         right = 20;
//       }
//       list.add(
//         Positioned(
//           top: top,
//           left: left,
//           right: right,
//           bottom: bottom,
//           child: Container(
//             decoration: BoxDecoration(
//               color: hotelList[i].isSelected ? AppTheme.primaryColor : AppTheme.backgroundColor,
//               borderRadius: BorderRadius.all(Radius.circular(24.0)),
//               boxShadow: <BoxShadow>[
//                 BoxShadow(
//                   color: AppTheme.secondaryTextColor,
//                   blurRadius: 16,
//                   offset: Offset(4, 4),
//                 ),
//               ],
//             ),
//             child: Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 borderRadius: BorderRadius.all(Radius.circular(24.0)),
//                 onTap: () {
//                   if (hotelList[i].isSelected == false) {
//                     state(() {
//                       hotelList.forEach((f) {
//                         f.isSelected = false;
//                       });
//                       hotelList[i].isSelected = true;
//                     });
//                   }
//                 },
//                 child: Padding(
//                   padding: const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 8),
//                   child: Text(
//                     "\$${hotelList[i].perNight}",
//                     style: TextStyle(
//                         color: hotelList[i].isSelected
//                             ? AppTheme.backgroundColor
//                             : AppTheme.primaryColor,
//                         fontSize: 18,
//                         fontWeight: FontWeight.w600),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ),
//       );
//     }
//     return list;
//   }
// }
