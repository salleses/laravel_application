import 'package:flutter/material.dart';

class HomeMovie extends StatelessWidget {
  const HomeMovie({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
