import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:new_motel/constants/text_styles.dart';
import 'package:new_motel/language/appLocalizations.dart';
import 'package:new_motel/logic/providers/theme_provider.dart';
import 'package:new_motel/models/enum.dart';
import 'package:new_motel/motel_app.dart';
import 'package:provider/provider.dart';

class VoucherScreen extends StatelessWidget {
  VoucherScreen({Key? key, required this.voucher}) : super(key: key);
  final dynamic voucher;

  final LanguageType _languageType = applicationcontext == null
      ? LanguageType.en
      : applicationcontext!.read<ThemeProvider>().languageType;

  final DateTime startDate = DateTime.now();
  final DateTime endDate = DateTime.now().add(Duration(days: 1));

  Widget _getappBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 0, top: 0 + 4.0, right: 24),
      child: Row(
        // mainAxisAlignment: MainAxisAlignment.center,
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            alignment: Alignment.centerLeft,
            // width: AppBar().preferredSize.height + 40,
            // height: AppBar().preferredSize.height,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.all(
                  Radius.circular(32.0),
                ),
                onTap: () {
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(Icons.arrow_back),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _getDateRoomUi(String title, String subtitle, BuildContext context) {
    return Expanded(
      child: Row(
        children: <Widget>[
          Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.all(
                Radius.circular(4.0),
              ),
              // onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.only(left: 8, right: 8, top: 4, bottom: 4),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      title,
                      // "Choose date",
                      style: TextStyles(context).getDescriptionStyle().copyWith(fontSize: 16),
                    ),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                      subtitle,
                      // "${DateFormat("dd, MMM").format(startDate)} - ${DateFormat("dd, MMM").format(endDate)}",
                      style: TextStyles(context).getRegularStyle(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.symmetric(horizontal: 8),
          children: [
            Padding(
              // padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
              padding: EdgeInsets.only(top: 8),
              child: Container(child: _getappBar(context)),
            ),
            Text(AppLocalizations(context).of("Voucher"),
                style: TextStyles(context).getBoldStyle().copyWith(fontSize: 22)),
            Text(
              "Dados da Reserva",
              maxLines: 2,
              textAlign: TextAlign.left,
              style: TextStyles(context).getBoldStyle().copyWith(fontSize: 24),
              overflow: TextOverflow.ellipsis,
            ),
            // Text(Helper.getRoomText(hotelInfo.roomData!))
            Text("lorem ipsum dsad hsj bjorn orninsten"),
            Container(
              decoration:
                  BoxDecoration(border: Border.all(color: Colors.grey.withOpacity(0.3), width: 1)),
              margin: EdgeInsets.only(bottom: 8, top: 8),
              padding: EdgeInsets.only(bottom: 8, top: 8),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                _getDateRoomUi(
                    AppLocalizations(context).of("date"),
                    "${DateFormat("dd, MMM", _languageType.toString().split(".")[1]).format(startDate)} - ${DateFormat("dd, MMM", _languageType.toString().split(".")[1]).format(endDate)}",
                    context),
                Container(
                  width: 1,
                  height: 42,
                  color: Colors.grey.withOpacity(0.8),
                ),
                _getDateRoomUi(
                    AppLocalizations(context).of("number_room"),
                    "${DateFormat("dd, MMM", _languageType.toString().split(".")[1]).format(startDate)} - ${DateFormat("dd, MMM", _languageType.toString().split(".")[1]).format(endDate)}",
                    context),
              ]),
            ),
            Padding(
              padding: EdgeInsets.only(top: 16, bottom: 8),
              child: Text(
                "Dados Pessoais",
                maxLines: 2,
                textAlign: TextAlign.left,
                style: TextStyles(context).getBoldStyle().copyWith(fontSize: 24),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text("lorem ipsum dsad hsj bjorn orninsten"),
            Padding(
              padding: EdgeInsets.only(top: 8, bottom: 8),
              child: TextFormField(
                initialValue: "Marcus Vinicius + Fonseca Antunes",
                decoration: InputDecoration(
                  labelText: "Nome",
                  border: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.grey.withOpacity(1),
                    ),
                  ),
                ),
              ),
            ),

            //TODO: Colocar validação de e-mail
            Padding(
              padding: EdgeInsets.only(top: 8, bottom: 8),
              child: TextFormField(
                initialValue: "marcus@teste.com",
                decoration: InputDecoration(
                  labelText: "E-mail",
                  border: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.grey.withOpacity(1),
                    ),
                  ),
                ),
              ),
            ),
            //TODO: Colocar validação de e-mail e igualidade com o e-mail principal
            Padding(
              padding: EdgeInsets.only(top: 8, bottom: 8),
              child: TextFormField(
                initialValue: "(45) 9 8765-1234",
                decoration: InputDecoration(
                  labelText: "Telefone",
                  border: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Colors.grey.withOpacity(1),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 16, bottom: 8),
              child: Text(
                "Dados de Pagamento",
                maxLines: 2,
                textAlign: TextAlign.left,
                style: TextStyles(context).getBoldStyle().copyWith(fontSize: 24),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Text("lorem ipsum dsad hsj bjorn orninsten"),
            Padding(
              padding: EdgeInsets.only(top: 8, bottom: 8),
              child: Row(children: [
                Flexible(
                  child: Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: TextFormField(
                      enabled: false,
                      initialValue: "Marcus Antunes",
                      decoration: InputDecoration(
                        labelText: "Nome no Cartão",
                        border: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.grey.withOpacity(1),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Flexible(
                  child: Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: TextFormField(
                      enabled: false,
                      initialValue: "3333",
                      decoration: InputDecoration(
                        labelText: "Final do cartão",
                        border: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.grey.withOpacity(1),
                          ),
                        ),
                      ),
                    ),
                  ),
                )
              ]),
            ),
            Padding(
              padding: EdgeInsets.only(top: 8, bottom: 8),
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.only(top: 8, bottom: 8, right: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Hotel:",
                          style: TextStyles(context).getBoldStyle(),
                        ),
                        Text(
                          "R\$ " + "125,00",
                          style: TextStyles(context).getBoldStyle(),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 8),
                    child: Container(
                      padding: EdgeInsets.only(top: 8, bottom: 8),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: Colors.grey.withOpacity(0.5),
                          ),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Taxa de Serviço:",
                            style: TextStyles(context).getBoldStyle(),
                          ),
                          Text(
                            "R\$ " + "25,00",
                            style: TextStyles(context).getBoldStyle(),
                          )
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 8, bottom: 8, right: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Total:",
                          style: TextStyles(context).getBoldStyle().copyWith(fontSize: 24),
                        ),
                        Text(
                          "R\$ " + "150,00",
                          style: TextStyles(context).getBoldStyle().copyWith(fontSize: 20),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
